#반복문(while)

# num1 = 1
# while num1 <= 5:
#     print("숫자:", num1)
#     num1 += 1

# num1 = 1
#
# while num1 <= 10:
#     print(num1)
#
#     if num1 == 6:
#         break
#
#     num1 += 1

# num = 0
# while num < 10:
#     num += 1
#
#     if num % 3 == 0:
#         continue
#
#     print(num)

# dan = 1
# while dan <= 9:
#     n = 1
#     while n <= 9:
#         print(f"{dan} X {n} = {dan * n}")
#         n += 1
#
#     dan += 1

#실습문제
#1. 1부터 100까지 짝수만 출력하기
# num = 1
# while num <= 100:
#     if num % 2 == 0:
#         print(num)
#
#     num += 1

#2. 5의 배수를 50까지 출력하기
#근데 이제 30에서 멈추기

num = 5
while num <= 50:
    print(num)

    if num == 30:
        break

    num += 5





