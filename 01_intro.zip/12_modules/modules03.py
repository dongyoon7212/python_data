from datetime import datetime, timedelta

#현재 날짜 및 시간
now = datetime.now() #현재 시스템의 날짜와 시간을 반환
print(now)

one_week_later = now + timedelta(days=7)
print(one_week_later)

formatted_date = now.strftime("%Y년 %m월 %d일 %H시 %M분 %S초")
print(formatted_date)


import os

print(os.getcwd()) #현재 작업 디렉토리의 경로를 출력
print(os.listdir()) #현재 작업 디렉토리 내의 모든 파일과 폴더를 출력

if not os.path.exists("new_folder"):
    os.mkdir("new_folder")

import re

pattern = r"\d{3}-\d{4}-\d{4}"
phone_number = "010-1234-5678"

if re.fullmatch(pattern, phone_number):
    print("올바른 전화번호")
else:
    print("잘못된 전화번호")


email_pattern = r"[a-zA-Z0-9._+-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,4}"
email = "dongyoon7212@naver.com"

if re.fullmatch(email_pattern, email):
    print("올바른 이메일")
else:
    print("잘못된 이메일")





