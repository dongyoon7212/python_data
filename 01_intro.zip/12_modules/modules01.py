import math

#ceil - 올림
print(math.ceil(3.14))

#copysign - 두번째 인자의 부호만 취해 첫번째 인자에 적용
print(math.copysign(3.14, -1))

#fabs - 절댓값을 반환하는 메소드
print(math.fabs(-12))

#factorial - 팩토리얼을 구하는 메소드
print(math.factorial(7))

#floor - 내림
print(math.floor(3.14))

#gcd - 두 수의 최대공약수
print(math.gcd(6, 8))

#modf - 정수 부분과 실수 부분을 분리해서 리턴
print(math.modf(3.14))

#trunc - 내림
print(math.floor(-3.14)) #무조건 아래로 내림
print(math.trunc(-3.14)) #0으로 향해서 내림

#log(a, b) - b를 밑으로 하는 log a에 대한 로그값을 반환
print(math.log(10, 10))

#pi - 원주율
print(math.pi)

# 사용자로부터 양수인 실수를 하나 입력받고
# 입력받은 숫자를 올림하여 출력하기
# 입력받은 숫자의 절댓값을 출력하기
user_input_num = input("실수를 입력하세요:")
user_num = float(user_input_num)

print(f"올림하여 출력: {math.ceil(user_num)}")
print(f"절댓값 출력: {math.fabs(user_num)}")



