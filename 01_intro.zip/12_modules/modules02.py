import random

print(random.random())

print(random.randint(1, 10))
print(random.randrange(1, 10, 2))

#shuffle
abc = ["a", "b", "c" , "d", "e"]
random.shuffle(abc)
print(abc)

#choice
print(random.choice(abc))

# 점심메뉴 후보를 리스트로 만들고
# 무작위로 하나의 메뉴를 선택하여 출력
#오늘의 점심메뉴는 .... 입니다!

lunch_list = ["돈까스", "돼지국밥", "비빔밥", "제육볶음", "뼈해장국"]
print(f"오늘의 점심메뉴는 {random.choice(lunch_list)} 입니다!")




