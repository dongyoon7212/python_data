#반복문(for)
from itertools import count

#리스트 순회
# fruits = ["사과", "바나나", "딸기", "포도"]
#
# for fruit in fruits:
#     print(fruit)

#딕셔너리 순회
# scores = {
#     "Alice": 85,
#     "Bob": 90,
#     "Charlie": 78,
#     "Max": 55
# }
#
# for key in scores:
#     print(f"{key}의 점수는 {scores[key]}점 입니다.")

#튜플 순회
# a_tuple = ("안녕", "하세요", "반갑습니다")
# for a in a_tuple:
#     print(a)

#세트 순회
# a_set = {"사과", "바나나", "체리", "딸기", "오렌지"}
# sorted_list = sorted(a_set)
# for a in sorted_list:
#     print(a)

# word = "python"
# for char in word:
#     print(char)

# list1 = list(range(1, 10, 2))
# print(list1)

# for i in range(5):
#     print(i)

# for i in range(2, 10, 2):
#     print(i)

# for i in range(1, 10):
#     print(i)
#     if i == 6:
#         break

# for i in range(1, 10):
#     if i == 5:
#         continue
#     print(i)

#1. 1부터 100까지 짝수만 출력하기
# for i in range(1, 101):
#     if i % 2 == 0:
#         print(i)

# for i in range(2, 101, 2):
#     print(i)

#2. 리스트의 합 구하기
numbers = [10, 20, 30, 40, 50]
result = 0

for num in numbers:
    result += num
print("총합:", result)

#3. 평균구하기
scores = [80, 90, 75, 88, 92]
total = 0

for score in scores:
    total += score

print("평균:", total/len(scores))

#4. 구구단 만들기
for dan in range(1, 10):
    for n in range(1, 10):
        print(f"{dan}X{n}={dan * n}")











