profile = {
    "이름": "이동윤",
    "나이": 27,
    "취미": ["여행", "음악", "영화"],
    "주소": "부산시 사하구 다대2동"
}

# print(profile["나이"])
# print(profile["취미"][2])

profile["나이"] = 28
# print(profile)

profile["직업"] = "IT 강사"
# print(profile)

del profile["직업"]
# profile.clear()
# print(profile)

#키만 불러오기
# print(list(profile.keys()))

#값만 불러오기
# print(list(profile.values()))

#키값 둘 다
# print(list(profile.items()))

python_grade = {
    "kelly": "B",
    "Json": "A",
    "Ian": "C",
    "Elly": "D"
}

#키 기준 오름차순
# print(sorted(python_grade.items()))
#키 기준 내림차순
# print(sorted(python_grade.items(), reverse=True))

#값 기준 오름차순
# print(sorted(python_grade.items(), key=lambda x: x[1]))
#값 기준 내림차순
# print(sorted(python_grade.items(), key=lambda x: x[1], reverse=True))

# student = {}
#이름을 입력받고 "이름"이라는 키의 값으로 넣기
#나이를 입력받고 "나이"라는 키의 값으로 넣기
#주소를 입력받고 "주소"라는 키의 값으로 넣기
# name = input("이름을 입력하세요:")
# student["이름"] = name
# age = input("나이를 입력하세요:")
# student["나이"] = age
# address = input("주소를 입력하세요:")
# student["주소"] = address

student = {
    "이름": input("이름을 입력하세요:"),
    "나이": input("나이를 입력하세요:"),
    "주소": input("주소를 입력하세요:")
}

print(student)











