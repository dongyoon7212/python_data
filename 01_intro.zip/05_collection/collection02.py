#튜플
colors = ("red", "blue", "green")
numbers = (1, 2, 3, 4, 5)
mixed = ("pink", 1, True)
single_tuple = ("hello",)
alphabet = ("a", "a", "a", "b", "b", "c")

print(colors[1])

# colors[1] = "yellow" 요소 변경 불가능

print(colors[:2])
print(colors[::-1])

#count
print(alphabet.count("a"))

#index
print(alphabet.index("c"))


#언패킹
a, b, c = colors
print(a, b, c)



