#세트
fruits = {"사과", "바나나", "오렌지", "바나나"}
print(fruits)
numbers = {1, 2, 2, 3, 3, 3, 4, 5, 6, 6, 6}
print(numbers)
empty_set = set()

#요소 추가
num = {1, 2, 3}
num.add(4)
print(num)

num.update([5, 6, 7])
print(num)

#요소 삭제
num.remove(4)
print(num)
num.discard(9)
print(num)

num.clear()
print(num)

A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

#합집합
print(A | B)
print(A.union(B))

#교집합
print(A & B)
print(A.intersection(B))

#차집합
print(A - B)
print(A.difference(B))

#문제
python_class = {"철수", "영희", "민수", "지수"}
java_class = {"영희", "민수", "지훈", "길동"}
#파이썬과 자바 수업 둘 다 듣는 학생 출력하기
#파이썬 수업만 듣는 학생 출력하기
#자바 수업만 듣는 학생 출력하기
print("파이썬, 자바 둘 다 듣는 학생:", python_class.intersection(java_class))
print("파이썬만 듣는 학생:", python_class.difference(java_class))
print("자바만 듣는 학생:", java_class.difference(python_class))





