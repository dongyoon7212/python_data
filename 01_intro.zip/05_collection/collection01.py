#List
fruits = ["apple", "banana", "cherry"]
numbers = [4, 5, 3, 1, 2]
bools = [True, False, False, True]
mixed_list = [1, "안녕하세요", True, 3.14]

print(fruits[1])
print(fruits[0][2])
print(numbers[-1])

fruits[1] = "blueberry"
print(fruits)

fruits.append("grape")
print(fruits)
fruits.insert(1, "mango")
print(fruits)

list1 = ["A", "B", "C"]
list2 = ["D", "E"]
print(list1 + list2)

print(list1 * 3)

list1.extend(list2)
print(list1)

fruits.remove("cherry")
print(fruits)
fruits.pop(1)
print(fruits)
del fruits[2]
print(fruits)

print(len(numbers))

print(numbers[1:3])
print(numbers[::-1])

numbers.sort(reverse=True)
print(numbers)

numbers2 = sorted(numbers)
print(numbers2)

has_two = 2 in numbers
print(has_two)

result = "-".join(list1)
print(result)

cart = []
#3개의 상품명을 입력받아서 cart에 추가
#3번 입력받고 각각 변수에 할당한 다음 각각 추가
# product1 = input("첫번째 상품:")
# product2 = input("두번째 상품:")
# product3 = input("세번째 상품:")
# cart.append(product1)
# cart.append(product2)
# cart.append(product3)
# print(cart)

# cart = [input("첫번째 상품:"), input("두번째 상품"), input("세번째 상품")]
# print(cart)

products = input("상품들을 입력하세요:")
print(products)
products_list = products.split(",")
print(products_list)
cart.extend(products_list)
print(cart)







