#조건문
"""
if 조건:
    실행할 코드
"""

num = 3
if num > 5:
    print("num은 5보다 큽니다.")
else:
    print("num은 5보다 작습니다.")

if num % 2 == 0:
    print("num은 짝수 입니다.")
else:
    print("num은 홀수 입니다.")

score = 73
#90이상이면 A출력
#80이상이면 B출력
#나머지 C
if score >= 90:
    print("A")
elif score >= 80:
    print("B")
elif score >= 70:
    print("C")
else:
    print("D")


#숫자를 하나 입력받고 해당 숫자가
#양수이면 양수입니다 출력
#음수이면 음수입니다 출력
num = input("숫자를 입력하세요: ")
num = int(num)
if num > 0:
    print("양수입니다.")
else:
    print("음수입니다.")


#나이를 입력받고 학생여부 입력받기(y/n)
#만약 20세 이상이면서 학생이면 성인학생입니다 출력
#만약 20세 이상이 아니면서 학생이면 청소년학생입니다 출력
#만약 20세 이상이면서 학생이 아니면 성인입니다 출력
#만약 20세 이상이 아니면서 학생이 아니면 일반인입니다 출력
age = int(input("나이를 입력하세요: "))
student = input("학생인가요? (y/n): ")
if age >= 20 and student == "y":
    print("성인학생입니다.")
elif not age >= 20 and student == "y":
    print("청소년학생입니다.")
elif age >= 20 and student == "n":
    print("성인입니다.")
elif not age >= 20 and student == "n":
    print("일반인입니다.")
# else:
#     print("일반인입니다.")


