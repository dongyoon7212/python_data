#requests 모듈

# import requests
#
# response = requests.get("https://www.naver.com")
# print(response.status_code)
# print(response.text)

#pandas 모듈
import pandas as pd

df_data = pd.read_csv("data.csv")
# print(df_data)
# print(df_data.describe())

"""
count - 해당 열의 데이터 갯수
mean - 평균값
std - 표준 편차 (데이터의 분산 정도)
min - 최솟값
25% - 1사분위 (25% 지점)
50% - 중앙값 (50% 지점, 중위수)
75% - 3사분위 (75% 지점)
max - 최댓값
"""

# print(df_data["Age"])
# print(df_data[["Age", "Salary"]])

import matplotlib.pyplot as plt
# df_data.groupby("Age")["Salary"].mean().plot(kind="bar")
# plt.title("연령별 평균 월급")
# plt.show()

# import numpy as np
#
# #1차원 배열
# arr1 = np.array([1, 2, 3, 4, 5])
# print(arr1)
#
# #2차원 배열
# arr2 = np.array([[1, 2, 3], [4, 5, 6]])
# print(arr2)
#
# #1로 다 채운 다차원 배열
# ones = np.ones((2, 3))
# print(ones)
#
# #0로 다 채운 다차원 배열
# zeros = np.zeros((4, 5))
# print(zeros)
#
# #특정한 값으로 다 채운 다차원 배열
# filled = np.full((3, 3), 7)
# print(filled)
#
# #랜덤 값으로 채운 다차원 배열
# random_int = np.random.randint(1, 100, (5, 6))
# print(random_int)
#
# #연속된 값으로 채운 다차원 배열
# arr_arange = np.arange(1, 10, 2)
# print(arr_arange)
#
# arr3 = np.array([1, 2, 3])
# arr4 = np.array([4, 5, 6])
#
# print(arr3 + arr4)
# print(arr3 - arr4)
# print(arr3 * arr4)
# print(arr3 / arr4)

import seaborn as sb

# categories = ["A", "B", "C", "D"]
# values = [3, 7, 1, 8]
# plt.bar(categories, values, color=["red", "blue", "green", "purple"])
# plt.show()

df_tips = pd.read_csv("tips.csv")

plt.figure(figsize=(8, 5))

sb.scatterplot(x="total_bill", y="tip", hue="sex", data=df_tips, palette="Set1")
"""
x="total_bill" => x축 설정: x축에 넣을 데이터의 칼럼명
hue="sex" => 색상 그룹화: 성별에 따라 다른 색상으로 표시
data="df_tips" => 데이터셋 설정: 그래프에 사용할 데이터를 설정
palette="Set1" => 색상 테마 적용
"""
plt.xlabel("Total Bill ($)")
plt.ylabel("Tip ($)")
plt.show()



