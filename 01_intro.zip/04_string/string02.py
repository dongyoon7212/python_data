a = "Life is too short, You need Python"
print(len(a))
print(a.count("t"))
print(a.index("t"))
print(a.index("t", 10, 18))
print(a.find("z"))

print("-".join(a))
print(a.lower())
print(a.upper())

b = "   hi    hi       "
print(b.lstrip())
print(b.rstrip())
print(b.strip())
print(a.replace("short", "long"))
print(a.replace(" ", ""))

print(a.split(" "))

#먼저 이메일을 입력받아서 변수에 저장하기
#해당 이메일에서 아이디만 추출해서 출력
#dongyoon7212@naver.com
#dongyoon7212
email = input("이메일을 입력하세요:")
idx = email.index("@")
print(email[:idx])



