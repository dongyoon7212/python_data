#문자열의 인덱스
# a = "Life is too short, You need Python"
# print(a[3])
# print(a[-1])
#
# b = a[0] + a[1] + a[2] + a[3]
# print(b)

#단어를 입력받고 해당 단어의 첫번째 글자와 마지막 글자를
#출력하시오.
#python
#첫번째 글자 - p
#마지막 글자 - n
# word = input("단어를 입력하세요:")
# print("첫번째 글자 -", word[0])
# print("마지막 글자 -", word[-1])
#

#슬라이싱
a = "Life is too short, You need Python"
print(a[0:4])
print(a[5:7])
print(a[19:])
print(a[:17])
print(a[:17:2])
print(a[::2])
print(a[::-1])

date = "20251215Cloudy"
#년도출력
print("년도:", date[:4])
#월일출력
print("월일:", date[4:8])
#날씨출력
print("날씨:", date[8:])


