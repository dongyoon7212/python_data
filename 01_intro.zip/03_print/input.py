#입력받기
#input()
# a = input()
# print(type(a))
# print("내가 입력한 값:", a)

username = input("이름을 입력하세요: ")
print("사용자 이름:", username)







