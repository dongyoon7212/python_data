print("hi" + "hello" + "world")
print("hi", "hello", "world")

name = "이동윤"
print("제 이름은" + name + "입니다.")

age = 27
# print("제 이름은" + age + "입니다.")

print("제 나이는 {} 입니다.".format(age))

print("제 이름은 {} 이고, 나이는 {}살 입니다.".format(name, age))
print("제 이름은 {n} 이고, 나이는 {a}살 입니다.".format(a=18, n="홍길동"))

print(f"제 이름은 {name} 이고, 나이는 {age}살 입니다.")

print("제 나이는 %s살 입니다." % age)

pie = 3.14
print("파이의 정수는 %d 입니다." % pie)

print("제 이름은 %s이고, 제 나이는 %d살 입니다." % (name, age))

print("Loading... %d%%" % 98)

print("%10s" % "hi")
print("%-10s" % "hi")

print("%0.4f" % 3.141565)
print("%10.4f" % 3.141565)

"""
%s => 문자열
%c => 문자
%d => 정수
%f => 실수
%o => 8진수
%x => 16진수
%% => 리터럴 (문자 % 그 자체)
"""




