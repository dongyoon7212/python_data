#산술 연산자
# num1 = 2
# num2 = 4
#
# print(f"num1 + num2 = {num1 + num2}") #덧셈
# print(f"num1 - num2 = {num1 - num2}") #뺄셈
# print(f"num1 * num2 = {num1 * num2}") #곱셈
# print(f"num1 / num2 = {num1 / num2}") #나눗셈(실수 몫)
# print(f"num1 // num2 = {num1 // num2}") #나눗셈(정수 몫)
# print(f"num1 % num2 = {num1 % num2}") #나머지
# print(f"num1 ** num2 = {num1 ** num2}")

#대입 연산자
x = 10
x += 5 # x = x + 5 => 15
x -= 3 # x = x - 3 => 12
x *= 2 # x = x * 2 => 24
#x /= 5 # x = x / 5 => 4.8
x //= 5 # x = x //5 => 4

#비교 연산자
x = 10
y = 20
z = 10
print(x == z) #True
print(x > y) #False
print(y == z) #False
print(x != z) #False
print(x >= y) #False
print(y >= z) #True

#논리 연산자
x = 10
y = 20
z = 10
print((y <= z) and (x == y))
print(not (x == y) and (y > z))
print((x == z) or (y < z))

#조건 연산자(삼항연산자)
a = 10
b = 20
max_value = a if a > b else b
print(max_value)

#홀짝 판별
num = 13
result = "짝수" if num % 2 == 0 else "홀수"
#num이 홀수면 result에 홀수
#num이 짝수면 result에 짝수

score = 73

#90점 이상이면 A
#80점 이상이면 B
#70점 이상이면 C
#나머지 D
grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D"
print(grade)




