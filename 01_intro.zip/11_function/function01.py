#사용자 정의 함수

# def hello():
#     print("반갑습니다.")
#
# hello()
# hello()
# hello()

# def plus(num1, num2):
#     print(num1 + num2)
#
# plus(10, 20)

# def hello(age, name="홍길동"):
#     print(f"{name}님 반갑습니다. {age}살")
#
# hello(27)

# def plus(x, y):
#     return x + y
#
# result = plus(10, 20)
# print(result)

#함수를 하나 정의하고 매개변수로 숫자를 한개 받아서
#7을 곱한 결과를 반환하는 함수로 만드시오
#그리고 호출할때 매개변수로 7을 전달한 결과값을 출력하시오
# def multiple_seven(num):
#     return num * 7
#
# print(multiple_seven(7))

# def cal_average(score_list):
#     total = sum(score_list)
#     return round(total / len(score_list))
#
# score_list1 = [55, 70, 100]
# print(cal_average(score_list1))


#콜백함수
#함수를 매개변수로 전달하여 필요할 때 호출하도록 하는 개념
#어떤 함수가 실행되는 동안 미리 정의된 다른 함수를 호출하여 실행

# def calculator(x, y, operation):
#     return operation(x, y)
#
# def plus(a, b):
#     return a + b
#
# def minus(a, b):
#     return a - b
#
# def multiple(a, b):
#     return a * b
#
# def divide(a, b):
#     return a / b

# print(calculator(3, 5, plus))
# print(calculator(10, 3, minus))

# import time
#
# def timer(pause_second, callback):
#     print(f"{pause_second}초 타이머가 시작되었습니다.")
#     print(f"{pause_second}초 후에 콜백함수가 실행됩니다.")
#
#     time.sleep(pause_second)
#
#     callback()
#     print("타이머가 종료되었습니다.")
#
# def hello():
#     print("안녕하세요.")
#
# timer(5, hello)

#lambda함수 (익명함수, 미시함수)
#특정 범위 내에서만 사용되거나 호출되는 횟수가 한 번인 경우 유용

# def plus(x, y):
#     return x + y
#
# add_lambda = lambda x, y: x + y
# print(add_lambda(3, 5))

# numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# map_result = map(lambda x: x * 2, numbers)
# result_list = list(map_result)
# print(result_list)

#숫자를 매개변수로 받아서 짝수면 "짝수"반환 홀수면 "홀수"반환
parity = lambda num: "짝수" if num % 2 == 0 else "홀수"
print(parity(4))

#콜백함수와 숫자 두개를 매개변수로 전달하고 해당 숫자 두개를
#나누는 콜백함수를 호출하여 나머지가 0이면 True 아니면 False
#반환하도록 만드시오 => 삼항연산자

def calculator(x, y, callback):
    return callback(x, y)

def divide(x, y):
    return True if x % y == 0 else False

print(calculator(8, 4, divide))










