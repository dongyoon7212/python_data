last_name = "이"
print(last_name)
first_name = "동윤"
print(first_name)
print(last_name + first_name)
name = "이동윤"
# print(name - first_name)

print(first_name * 3)

age = 27
print(age * 3)
pie = 3.14

str1 = """
안녕하세요
반갑습니다
"""
print(str1)


num1 = 2.1
num2 = 4.2
print(num1 + num2)
"""
컴퓨터는 이진수만 저장을 하게 되는데 소수는 정확하게 떨어지는 이진법으로
저장이 불가능하다.
그래서 근사값을 저장하고 연산을 하게 되면서 실제의 값보다 아주 조금 더 크게
결과가 나온다.
"""

#boolean
is_mz = True
is_empty = False

str3 = "python"
str4 = ""










