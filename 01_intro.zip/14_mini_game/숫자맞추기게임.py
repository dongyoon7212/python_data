import random

difficulty_list = ["쉬움", "보통", "어려움"]
difficulty = ""
max_try = 0
max_range = 0

while True:
    difficulty = input("난이도를 선택하세요. (쉬움, 보통, 어려움):")
    if difficulty in difficulty_list:
        break
    else:
        print("다시 입력해주세요.")
        continue

if difficulty == "쉬움":
    max_try = 7
    max_range = 50
elif difficulty == "보통":
    max_try = 5
    max_range = 75
else:
    max_try = 3
    max_range = 100

correct_answer = random.randint(1, max_range)

try_count = 0

print(f"숫자 맞추기 게임을 시작하겠습니다.\n난이도: {difficulty}, 최대 시도 가능 횟수: {max_try}")

while True:
    print(f"시도횟수: {try_count}/{max_try}")

    if try_count >= max_try:
        print("<게임 오버>")
        print("시도 횟수를 초과하였습니다.")
        print(f"정답은 {correct_answer}")
        break

    input_str = input("숫자를 맞춰보세요: ")
    guess = 0
    if input_str.isdigit():
        guess = int(input_str)
    else:
        print("숫자로 다시 입력해주세요.")
        continue

    if guess < 1 or guess > max_range:
        print("범위 내의 숫자를 입력해주세요.")
        continue

    if correct_answer > guess:
        print("UP!!")
    elif correct_answer < guess:
        print("DOWN!!")
    else:
        print(f"정답입니다! {try_count}번 만에 맞췄습니다!")
        break

    try_count += 1
    








